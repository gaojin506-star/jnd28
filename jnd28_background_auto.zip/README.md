# jnd28 后台自动版

需要把这些文件全部上传到仓库根目录，并保持目录结构：

- `index.html`
- `data/state.json`
- `scripts/update.mjs`
- `.github/workflows/auto-update.yml`

上传完成后到 GitHub 仓库：
**Actions → Auto update predictions → Run workflow**
先手动运行一次。

之后工作流会按计划自动运行并更新 `data/state.json`。
网页每15秒读取一次最新状态。

注意：GitHub 定时任务不是硬实时服务，可能有调度延迟；脚本在每次任务里约每55秒轮询一次、连续5次，用来降低漏掉期数的概率。


import fs from "fs";

const BASE = "https://pc28.help";
const STATE_FILE = "data/state.json";
const combosAll = ["大单","大双","小单","小双"];
const SIM_START = 300, SIM_TARGET = 500, SIM_BASE = 5;
const MIN_CONF = 58;

function loadState(){
  try { return JSON.parse(fs.readFileSync(STATE_FILE,"utf8")); }
  catch { throw new Error("无法读取 state.json"); }
}
function saveState(s){
  s.updatedAt = new Date().toISOString();
  fs.writeFileSync(STATE_FILE, JSON.stringify(s,null,2));
}
async function getJson(path){
  const r = await fetch(BASE+path, {headers:{"user-agent":"jnd28-background-updater/1.0"}});
  if(!r.ok) throw new Error(`${path} HTTP ${r.status}`);
  return await r.json();
}
function classify(sum){
  return (sum<=13?"小":"大") + (sum%2===0?"双":"单");
}
function normalizeCombo(v){
  const s=String(v||"").replace(/\s+/g,"");
  return combosAll.find(x=>s.includes(x)) || null;
}
function getRows(kj){
  return (kj.data||[]).map((r,i)=>({
    issue:String(r.nbr||""),
    sum:Number(r.number),
    combo:r.combination || classify(Number(r.number)),
    idx:i
  })).filter(r=>Number.isFinite(r.sum) && r.issue);
}
function algo1(kj,sz,sha){
  const rows=getRows(kj).slice(0,100);
  const primary=normalizeCombo(sz?.data?.[0]?.predict) || rows[0]?.combo || "大单";
  const kill=normalizeCombo(sha?.data?.[0]?.predict) || null;
  const counts=Object.fromEntries(combosAll.map(c=>[c,0]));
  rows.forEach(r=>counts[r.combo]++);
  let candidates=combosAll.filter(c=>c!==primary && c!==kill);
  if(!candidates.length)candidates=combosAll.filter(c=>c!==primary);
  candidates.sort((a,b)=>counts[b]-counts[a]);
  const second=candidates[0];
  let confidence=52;
  if(kill && kill!==primary && kill!==second) confidence+=10;
  const topFreq=Math.max(counts[primary]||0,counts[second]||0);
  confidence+=Math.min(18,Math.round(topFreq/Math.max(1,rows.length)*40));
  return {combos:[primary,second],kill:kill||combosAll.find(c=>![primary,second].includes(c)),confidence:Math.min(85,confidence)};
}
function algo2(kj){
  const rows=getRows(kj).slice(0,36);
  const score=Object.fromEntries(combosAll.map(c=>[c,0]));
  const transitions={};
  rows.forEach((r,i)=>{
    const w=Math.max(.25,1-i*.024);
    score[r.combo]+=w;
    if(i+1<rows.length){
      const prev=rows[i+1].combo, cur=r.combo;
      transitions[prev] ||= Object.fromEntries(combosAll.map(c=>[c,0]));
      transitions[prev][cur]+=w;
    }
  });
  const latest=rows[0]?.combo;
  const trans=latest && transitions[latest] ? transitions[latest] : {};
  const rank=combosAll.map(c=>({c,s:score[c]+(trans[c]||0)*1.35})).sort((a,b)=>b.s-a.s);
  const total=rank.reduce((s,x)=>s+x.s,0)||1;
  return {combos:[rank[0].c,rank[1].c],kill:rank.at(-1).c,confidence:Math.min(88,Math.round((rank[0].s+rank[1].s)/total*100))};
}
function algo3(kj){
  const rows=getRows(kj).slice(0,100);
  const windows=[20,50,100];
  const blended=Object.fromEntries(combosAll.map(c=>[c,0]));
  for(const [wi,w] of windows.entries()){
    const part=rows.slice(0,w);
    const counts=Object.fromEntries(combosAll.map(c=>[c,0]));
    part.forEach(r=>counts[r.combo]++);
    const weight=[0.25,0.30,0.45][wi];
    combosAll.forEach(c=>blended[c]+=counts[c]/Math.max(1,part.length)*weight);
  }
  // Mild anti-crowding: if a combo just appeared repeatedly, trim score slightly.
  const recent=rows.slice(0,5).map(r=>r.combo);
  combosAll.forEach(c=>{
    const streak=recent.filter(x=>x===c).length;
    blended[c]-=streak*0.008;
  });
  const rank=combosAll.map(c=>({c,s:blended[c]})).sort((a,b)=>b.s-a.s);
  const total=rank.reduce((s,x)=>s+x.s,0)||1;
  return {combos:[rank[0].c,rank[1].c],kill:rank.at(-1).c,confidence:Math.min(86,Math.round((rank[0].s+rank[1].s)/total*100))};
}
function settleRecord(algoState, actual){
  const cur=algoState.current;
  if(!cur || cur.issue!==actual.issue) return;
  const comboHit=cur.combos.includes(actual.combo);
  const killSuccess=cur.kill ? actual.combo!==cur.kill : null;
  algoState.records.unshift({
    issue:actual.issue, combos:cur.combos, kill:cur.kill, confidence:cur.confidence,
    actualCombo:actual.combo, actualSum:actual.sum, comboHit, killSuccess,
    settledAt:new Date().toISOString()
  });
  algoState.records=algoState.records.slice(0,100);
  algoState.current=null;
}
function settleSim(sim, actual){
  const p=sim.pending;
  if(!p || p.issue!==actual.issue) return;
  const hit=p.combos.includes(actual.combo);
  if(hit){
    sim.points += sim.stake;
    sim.net += sim.stake;
    sim.step=1; sim.stake=SIM_BASE;
  }else{
    const loss=sim.stake*2;
    sim.points -= loss; sim.net -= loss;
    sim.step += 1; sim.stake *= 2;
  }
  sim.pending=null;
  if(sim.points>=SIM_TARGET){
    sim.success++; sim.history.unshift({round:sim.round,result:"成功",endPoints:sim.points,endedAt:new Date().toISOString()});
    sim.round++; sim.points=SIM_START; sim.step=1; sim.stake=SIM_BASE;
  } else if(sim.points<=0 || sim.points < sim.stake*2){
    sim.fail++; sim.history.unshift({round:sim.round,result:"失败",endPoints:Math.max(0,sim.points),endedAt:new Date().toISOString()});
    sim.round++; sim.points=SIM_START; sim.step=1; sim.stake=SIM_BASE;
  }
  sim.history=sim.history.slice(0,100);
}
function ensurePrediction(algoState, sim, issue, pred){
  if(!algoState.current || algoState.current.issue!==issue){
    algoState.current={issue, ...pred, createdAt:new Date().toISOString()};
  }
  if(!sim.pending && pred.confidence>=MIN_CONF){
    sim.pending={issue,combos:[...pred.combos],confidence:pred.confidence,createdAt:new Date().toISOString()};
  }
}
async function tick(){
  const state=loadState();
  const [kj,sz,sha]=await Promise.all([
    getJson("/api/kj.json?nbr=100"),
    getJson("/api/sz.json?nbr=1"),
    getJson("/api/sha.json?nbr=1")
  ]);
  const rows=getRows(kj);
  if(!rows.length) throw new Error("开奖接口没有数据");

  const latest=rows[0];
  state.latestDraw={issue:latest.issue,sum:latest.sum,combo:latest.combo};
  state.nextIssue=String(Number(latest.issue)+1);

  for(const id of ["a1","a2","a3"]){
    settleRecord(state.algorithms[id], latest);
    settleSim(state.simulations[id], latest);
  }

  const p1=algo1(kj,sz,sha), p2=algo2(kj), p3=algo3(kj);
  ensurePrediction(state.algorithms.a1,state.simulations.a1,state.nextIssue,p1);
  ensurePrediction(state.algorithms.a2,state.simulations.a2,state.nextIssue,p2);
  ensurePrediction(state.algorithms.a3,state.simulations.a3,state.nextIssue,p3);

  saveState(state);
  console.log(`updated ${state.latestDraw.issue} -> ${state.nextIssue}`);
}

const loops = Number(process.env.POLL_LOOPS || 1);
const sleepMs = Number(process.env.POLL_INTERVAL_MS || 0);

for(let i=0;i<loops;i++){
  try { await tick(); }
  catch(e){ console.error(e); if(i===loops-1) process.exitCode=1; }
  if(i<loops-1 && sleepMs>0) await new Promise(r=>setTimeout(r,sleepMs));
}
